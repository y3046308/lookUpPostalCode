#!/bin/bash

ORACLE_INSTANTCLIENT_FOLDER=/usr/lib/oracle/12.1/client64/
ORACLE_SQLPLUS_BINARY=bin/sqlplus

ORACLE_USERNAME=
ORACLE_PASSWORD=
HOST=
INSTANCE=test01
ASSYSDBA=0

VERBOSE=0

usage() {
cat << EOF
usage: $0 -h  -u  -p  [-i ] [-s] [-v]

This script connects to the specified Oracle instance and executes a simple
statement. If that statement succeeds, the script returns 0.

OPTIONS:
   -h      Specify the host (required)
   -u      Oracle username (required)
   -p      Oracle password for the user (required)
   -i      SID of the instance (default: test01)
   -s      Force login AS SYSDBA
   -v      Verbose
EOF
}


while getopts "u:p:i:h:vs" OPTION; do
        case $OPTION in
                u)
                        ORACLE_USERNAME=$OPTARG
                        ;;
                p)
                        ORACLE_PASSWORD=$OPTARG
                        ;;
                i)
                        INSTANCE=$OPTARG
                        ;;
                v)
                        VERBOSE=1
                        ;;
                h)
                        HOST=$OPTARG
                        ;;
                s)
                        ASSYSDBA=1
                        ;;
                ?)
                        usage
                        exit 1
                        ;;
        esac
done

if [ -z "$ORACLE_USERNAME" ]; then
        echo "You must specify a username (-u)!"
        usage
        exit 1
fi


if [ -z "$ORACLE_PASSWORD" ]; then
        echo "You must specify a password (-p)!"
        usage
        exit 1
fi


if [ -z "$HOST" ]; then
        echo "You must specify a host (-h)!"
        usage
        exit 1
fi

if [[ "$ORACLE_USERNAME" == "sys" || "$ORACLE_USERNAME" == "SYS" ]]; then
        ASSYSDBA=1
fi

export LD_LIBRARY_PATH=$ORACLE_INSTANTCLIENT_FOLDER/lib
export ORACLE_SID=$INSTANCE

CONNECT_STRING=$(echo $ORACLE_USERNAME/$ORACLE_PASSWORD@$HOST/$INSTANCE)

if [ $ASSYSDBA -eq 1 ]; then
        CONNECT_STRING="$CONNECT_STRING AS SYSDBA"
fi

SPOUT=$($ORACLE_INSTANTCLIENT_FOLDER/$ORACLE_SQLPLUS_BINARY -S "$CONNECT_STRING" << EOF
SET ECHO OFF
SET HEADING OFF
SELECT to_char(sysdate,'yyyy-mm-dd') FROM dual;
EOF
)

if [ $? -eq 0 ]; then
        TRIMMED=$(echo $SPOUT)
        echo "OK: $ORACLE_USERNAME@$INSTANCE, sysdate='$TRIMMED'"
        if [ $VERBOSE -eq 1 ]; then
                echo "| host=$HOST, username=$ORACLE_USERNAME, instance=$INSTANCE, as_sysdba=$ASSYSDBA"
        fi
        exit 0
else
        # Remove the \n from the output of SQL*Plus
        SPOUT=$(echo $SPOUT | tr '\n' ' ')
        echo "ERROR: sqlplus returned $? : $SPOUT"
        echo " | CONNECT_STRING=$CONNECT_STRING"
        exit 2
fi
