locations=( toronto cornwall brockville ottawa pembroke kingston trenton northyork richmondhill mississauga barrie bracebridge hamilton kitchener london goderich owensound chatham pointedward techumseh northbay timmins sudbury saultstemarie dryden fortfrances kenora thunderbay )

for l in "${locations[@]}"
do

#sudo rm $l.sh

sudo cp peterborough.sh $l.sh
sed -i 's/peterborough/'"$l"'/g' $l.sh

done


