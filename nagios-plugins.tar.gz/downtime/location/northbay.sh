sudo /usr/local/nagios/libexec/downtime/nagios_down.php -Hh -g location-northbay-hosts -f -b "$1" -e "$2" -a "$3" -c "$4"
sudo /usr/local/nagios/libexec/downtime/nagios_down.php -Hs -g location-northbay-hosts -f -b "$1" -e "$2" -a "$3" -c "$4"
