#!/bin/bash
groups=( Infrasys-windows-servers-nonprod Infrasys-windows-servers app-4yc-hosts App-aim-hosts App-amp2-hosts App-b2b-hosts App-b2bsoa-hosts app-bridge-servers App-connect-hosts App-csi-hosts App-dts-hosts App-edex-hosts App-fieldworker-hosts App-giswebservices-hosts app-insight-f12-hosts app-insight-mvp-hosts app-insight-proforma-hosts app-insight-reportr-hosts app-insight-valuer-hosts App-msm-hosts App-other-hosts App-peopleregistry-hosts App-rds-hosts App-SAP-AWS-Hosts App-source-acs-hosts app-vaas-bridge-hosts app-vaas-extractor-hosts app-vaas-hosts app-vaas-orchestrator-hosts app-vaas-projector-hosts app-vaas-pulsar-hosts app-vaas-valuationtree-hosts app-vaas-vector-hosts App-vde-hosts App-webnotice-hosts App-wms-hosts App-www.mpac.ca-hosts Infranet-AP-PING Infranet-AWS-New-VPC-Primary-Tunnel Infranet-AWS-Old-VPC-Primary-Tunnel Infranet-backbone-switches Infranet-backbone-switches-PING Infranet-Content-Filtering-Devices Infranet-Domain-Registries Infranet-Field-Office-Hosts Infranet-Remote-Access-Devices Infranet-Security-Firewall-Devices Infranet-Security-IPS-Devices Infranet-Security-NAC-Device Infranet-switches Infranet-Threat-Detection-Devices Infrasys-Anti-Virus-and-Security-Hosts Infrasys-Authentication-and-Authorization-Hosts Infrasys-Backup-and-Storage-Hosts Infrasys-dmz-servers Infrasys-dmz-servers-nonprod Infrasys-Endpoint-Device-Management-Hosts Infrasys-File-and-Print-Hosts Infrasys-File-Print-Hosts Infrasys-File-Transfer-Hosts Infrasys-linux-hosts Infrasys-linux-servers-nonprod Infrasys-Mobile-Device-Management-Hosts Infrasys-nrpe-nodes Infrasys-nrpe-nodes-nonprod Infrasys-Office365-Collaboration-Hosts Infrasys-Patching-Management-Hosts Infrasys-Printer-Scanner-Fax-Devices Infrasys-Remote-Terminal-Hosts Infrasys-SharePoint-Collaboration-Hosts Infrasys-Software-Licenses-Hosts Infrasys-unix-servers Infrasys-virtual-nodes )

for i in "${!groups[@]}"
do

echo "${array[$i]}"
sudo /usr/local/nagios/libexec/downtime/nagios_down.php -Hh -g "${groups[$i]}" -f -b "$1" -e "$2" -a "$3" -c "$4" 
sudo /usr/local/nagios/libexec/downtime/nagios_down.php -Hs -g "${groups[$i]}" -f -b "$1" -e "$2" -a "$3" -c "$4" 


done
