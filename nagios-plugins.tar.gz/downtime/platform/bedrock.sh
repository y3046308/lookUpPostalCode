sudo /usr/local/nagios/libexec/downtime/nagios_down.php -Ss -g App-b2bsoa-services -f -b "$1" -e "$2" -a "$3" -c "$4"
sudo /usr/local/nagios/libexec/downtime/nagios_down.php -Sh -g App-b2bsoa-services -f -b "$1" -e "$2" -a "$3" -c "$4"
