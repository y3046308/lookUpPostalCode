sudo /usr/local/nagios/libexec/downtime/nagios_down.php -Ss -g "$1" -f -b "$2" -e "$3" -a "$4" -c "$5"
sudo /usr/local/nagios/libexec/downtime/nagios_down.php -Sh -g "$1" -f -b "$2" -e "$3" -a "$4" -c "$5"
