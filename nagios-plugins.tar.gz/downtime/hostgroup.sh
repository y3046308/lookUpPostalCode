sudo /usr/local/nagios/libexec/downtime/nagios_down.php -Hs -g "$1" -f -b "$2" -e "$3" -a "$4" -c "$5"
sudo /usr/local/nagios/libexec/downtime/nagios_down.php -Hh -g "$1" -f -b "$2" -e "$3" -a "$4" -c "$5"
