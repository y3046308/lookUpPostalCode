#!/usr/bin/perl -w

#
# $Id: check_printer_info.pl / Version 1.00 / 2010-07-01 10:48 / projects@thesysadmin.net
#
# Copyright (C) 2010 Martin Mueller,
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
# Report bugs to:  projects@thesysadmin.net
#
#
# CHANGELOG:
#
# 1.00 - 01.07.2010 - First public version
#

$ENV{'PATH'}='';
$ENV{'BASH_ENV'}='';
$ENV{'ENV'}='';

use POSIX;
use warnings;
use strict;


# Find the Nagios::Plugin lib. Change this path if necessary
use FindBin;
use lib "$FindBin::Bin/../perl/lib";
use Nagios::Plugin qw(%ERRORS);

#use Net::SNMP qw(TRANSLATE_NONE);
use Net::SNMP;
use Getopt::Long qw(:config no_ignore_case bundling);

# define Constants

use vars qw($PROGRAMNAME $SHORTNAME $AUTHOR $COPYR $VERSION);
$PROGRAMNAME = "$FindBin::Script";
$SHORTNAME = "Printer Infos";
$AUTHOR = "Martin Mueller";
$COPYR = "Copyright (C) 2010";
$VERSION = "Version: 1.00";

sub usage();
sub help();

# define Commandline-Options

my $host = undef;
my $community = "public";
my $snmp_version = 1;
my $snmp_port = 161;
my $type = undef;
my $timeout = 15;
my $help = undef;
my $printversion = undef;


my $np = Nagios::Plugin->new(
                shortname => "$SHORTNAME",
);

# get Options

GetOptions(
   "H|host=s"           => \$host,
   "C|community=s"      => \$community,
   "p|snmp_port=i"      => \$snmp_port,
   "v|snmp_version=i"   => \$snmp_version,
   "T|type=s"           => \$type,
   "t|timeout=i"        => \$timeout,
   "h|help"             => \$help,
   "V|version"          => \$printversion,
   );

if ($help) {
	help();
	}

if ($printversion) {
	printf "\n";
	printf "$PROGRAMNAME - $VERSION\n\n";
	printf "$COPYR $AUTHOR\n";
	printf "This programm comes with ABSOLUTELY NO WARRANTY\n";
	printf "This programm is licensed under the terms of the GNU General Public License";
	printf "\n\n";
	exit($ERRORS{'UNKNOWN'});
	}

if (!defined $host) {
	printf "\nMissing argument [host]. Please specify a hostname or ip address\n";
	usage();
	}

if ($snmp_version =~ /[^12]/) {
	printf "\nSNMP version: $snmp_version is not supported. Please use SNMP version 1 or 2\n";
	usage();
	}

if (!defined $type) {
        printf "\nMissing argument [type]. Please specify a printer-type ( hp | intermec | ricoh )\n";
        usage();
        }

# Just in case of problems, let's not hang Nagios
$SIG{'ALRM'} = sub {
	$np->nagios_die("No snmp response from $host (alarm)");
	};

alarm($timeout);

# ------------------------------------------------------
# Start here with Main Program
# ------------------------------------------------------

my $session;
my $error;

my $oid_hp_sn = ".1.3.6.1.2.1.43.5.1.1.17.1";
my $oid_hp_type = ".1.3.6.1.2.1.25.3.2.1.3.1";
my $oid_hp_pagecount = ".1.3.6.1.2.1.43.10.2.1.4.1.1";

my $oid_ricoh_sn = ".1.3.6.1.4.1.367.3.2.1.2.1.4.0";
my $oid_ricoh_type = ".1.3.6.1.2.1.25.3.2.1.3.1";
my $oid_ricoh_pagecount = ".1.3.6.1.4.1.367.3.2.1.2.19.5.1.9.1";
my $oid_ricoh_pagecount_copier = ".1.3.6.1.4.1.367.3.2.1.2.19.5.1.9.2";
my $oid_ricoh_pagecount_printer = ".1.3.6.1.4.1.367.3.2.1.2.19.5.1.9.6";
my $oid_ricoh_pagecount_facsimile = ".1.3.6.1.4.1.367.3.2.1.2.19.5.1.9.4";
my $oid_ricoh_pagecount_duplex = ".1.3.6.1.4.1.367.3.2.1.2.19.5.1.9.10";

my $oid_intermec_type = ".1.3.6.1.2.1.25.3.2.1.3.1";
my $oid_intermec_application = ".1.3.6.1.4.1.1963.25.2.1.5.0";
my $oid_intermec_version = ".1.3.6.1.4.1.1963.25.2.1.6.0";

my $printer_sn = "";
my $printer_type = "";
my $printer_pagecount = "";
my $printer_pagecount_copier = "";
my $printer_pagecount_printer = "";
my $printer_pagecount_facsimile = "";
my $printer_pagecount_duplex = "";
my $printer_application = "";
my $printer_version = "";

&create_snmpsession();

if (lc($type) eq "hp") {

	$printer_type = &get_snmpdata($oid_hp_type);

	if ($printer_type=~/^HP Color LaserJet 2600n/i) {
		$printer_sn = "n/a";
		$printer_pagecount = 0;
		}
	else {
		$printer_sn = &get_snmpdata($oid_hp_sn);
		$printer_pagecount = &get_snmpdata($oid_hp_pagecount);
		}

	$np->add_message('OK',"Type: $printer_type");
	$np->add_message('OK',"SN: $printer_sn");
	$np->add_message('OK',"Page-Count: $printer_pagecount");

	$np->add_perfdata(
        	label => "Overall_printedPages",
        	value => $printer_pagecount,
#		uom => "c",
		);

        $np->add_perfdata(
                label => "printedPages",
                value => $printer_pagecount,
                uom => "c",
        	);
	}
elsif (lc($type) eq "ricoh") {
	$printer_type = &get_snmpdata($oid_ricoh_type);
	$printer_sn = &get_snmpdata($oid_ricoh_sn);
	$printer_pagecount = &get_snmpdata($oid_ricoh_pagecount);
	$printer_pagecount_copier = &get_snmpdata($oid_ricoh_pagecount_copier);
	$printer_pagecount_printer = &get_snmpdata($oid_ricoh_pagecount_printer);
	$printer_pagecount_facsimile = &get_snmpdata($oid_ricoh_pagecount_facsimile);
	$printer_pagecount_duplex = &get_snmpdata($oid_ricoh_pagecount_duplex);

        $np->add_message('OK',"Type: $printer_type");
        $np->add_message('OK',"SN: $printer_sn");
        $np->add_message('OK',"Page-Count: $printer_pagecount");
        $np->add_message('OK',"Page-Count_Copier: $printer_pagecount_copier");
        $np->add_message('OK',"Page-Count_Printer: $printer_pagecount_printer");
        $np->add_message('OK',"Page-Count_Facsimile: $printer_pagecount_facsimile");
        $np->add_message('OK',"Page-Count_Duplex: $printer_pagecount_duplex");

        $np->add_perfdata(
                label => "Overall_printedPages",
                value => $printer_pagecount,
                );
        $np->add_perfdata(
                label => "printedPages",
                value => $printer_pagecount,
                uom => "c",
                );
        $np->add_perfdata(
                label => "Overall_printedPages_Copier",
                value => $printer_pagecount_copier,
                );
        $np->add_perfdata(
                label => "printedPages_Copier",
                value => $printer_pagecount_copier,
                uom => "c",
                );
        $np->add_perfdata(
                label => "Overall_printedPages_Printer",
                value => $printer_pagecount_printer,
                );
        $np->add_perfdata(
                label => "printedPages_Printer",
                value => $printer_pagecount_printer,
                uom => "c",
                );
        $np->add_perfdata(
                label => "Overall_printedPages_Facsimile",
                value => $printer_pagecount_facsimile,
                );
        $np->add_perfdata(
                label => "printedPages_Facsimile",
                value => $printer_pagecount_facsimile,
                uom => "c",
                );
        $np->add_perfdata(
                label => "Overall_printedPages_Duplex",
                value => $printer_pagecount_duplex,
                );
        $np->add_perfdata(
                label => "printedPages_Duplex",
                value => $printer_pagecount_duplex,
                uom => "c",
                );

	}
elsif (lc($type) eq "intermec") {
	$printer_type = &get_snmpdata($oid_intermec_type);

	if ($printer_type=~/^Intermec Intermec EasyLAN 100i/i) {
	        $np->add_message('OK',"Type: Intermec EasyCoder F4");
		}
	else {
		$printer_application = &get_snmpdata($oid_intermec_application);
		$printer_version = &get_snmpdata($oid_intermec_version);

	        $np->add_message('OK',"Type: $printer_type");
	        $np->add_message('OK',"Application: $printer_application $printer_version");
		}
	}
else {
	$np->add_message('WARNING'," anything went wrong :-(");
	## Nothing to do
	}


&end_snmpsession();

# Create Nagios-Output and End the Plugin

my ($code, $message) = $np->check_messages(join => "<BR>",join_all => "<BR>");
$np->nagios_exit($code,$message);

# ------------------------------------------------------
# End Main Program
# ------------------------------------------------------

sub create_snmpsession() {
	($session,$error) = Net::SNMP->session(Hostname => $host, Community => $community, Port => $snmp_port, Version => $snmp_version);
	$np->nagios_die("Unable to open SNMP connection. ERROR: $error") if (!defined($session));
	}

sub end_snmpsession() {
	$session->close;
	alarm(0);
	}

sub get_snmpdata() {
	my $oid_requested = $_[0];
	my $oid_option = $_[1];
	my $oid_value_hash;
	my $oid_value;
	my $session;
	my $error;

        ($session,$error) = Net::SNMP->session(Hostname => $host, Community => $community, Port => $snmp_port, Version => $snmp_version);
	$np->nagios_die("Unable to open SNMP connection. ERROR: $error") if (!defined($session));	

# if OID-Option is given ask them, otherwise do oid only

	if (defined $oid_option) {
		$oid_value_hash = $session->get_request($oid_requested.$oid_option);
		$np->nagios_die("Unable to read SNMP-OID. ERROR: ".$session->error()) if (!defined($oid_value_hash));
        	$oid_value = $oid_value_hash->{$oid_requested.$oid_option};
		}
	else {
                $oid_value_hash = $session->get_request($oid_requested);
		$np->nagios_die("Unable to read SNMP-OID. ERROR: ".$session->error()) if (!defined($oid_value_hash));
                $oid_value = $oid_value_hash->{$oid_requested};
		}

        $session->close;
	alarm(0);

        return $oid_value;
        }

sub usage () {
	printf "\n";
	printf "\n$PROGRAMNAME $VERSION\n";
	printf "$COPYR $AUTHOR\n";
	printf "This programm comes with ABSOLUTELY NO WARRANTY\n";
	printf "This programm is licensed under the terms of the GNU General Public License\n\n";
	printf "USAGE: \n$PROGRAMNAME -H <hostname> [-C <community>] -T <type>\n\n";
	printf "For detailed help use: $PROGRAMNAME --help\n\n";
	exit($ERRORS{'UNKNOWN'});
	}

sub help () {
	printf "\n\n$PROGRAMNAME plugin for Nagios \n";
	printf "$COPYR $AUTHOR\n";
	printf "This programm comes with ABSOLUTELY NO WARRANTY\n";
	printf "This programm is licensed under the terms of the GNU General Public License\n\n";
	printf "collects general information about your printer via SNMP.\n";
	printf "Following Infos will be collected: Modell, Serialnumber, Printed Pages (Perfdata)\n";
	printf "To use this Plugin your Printers must have SNMP enabled.\n";
	printf "\nUsage:\n";
	printf "   -H (--hostname)      Hostname to query - (required)\n";
	printf "   -C (--community)     SNMP read community (default=public)\n";
	printf "   -v (--snmp_version)     1 for SNMP v1 (default)\n";
	printf "                           2 for SNMP v2c\n";
	printf "   -p (--snmp_port)     SNMP Port (default=161)\n";
	printf "   -T (--type)          Specify one Printer-Type (required)\n";
	printf "                           hp       - Checks HP-Printer-Infos\n";
	printf "                           ricoh    - Checks Ricoh-(All-in-One)-Infos\n";
	printf "                           intermec - Checks Intermec-(Easycoder)-Printer-Infos (no Performance-Data)\n";
	printf "   -t (--timeout)       Seconds before the plugin times out (default=15)\n";
	printf "   -V (--version)       Plugin version\n";
	printf "   -h (--help)          Usage help \n\n";
	exit($ERRORS{'OK'});
}

