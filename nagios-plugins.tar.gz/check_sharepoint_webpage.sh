#!/bin/bash

# VERSION 0.2 
# A simple BASH shell script that attempts to log into Microsoft Sharepoint URL 
# and evaluate header information for a  HTTP/1.1 200 OK status code.
# At current it only outputs OK or CRITICAL.
# Modeled on the check_exchange_webmail.sh plugin from user nagiosexchange

# 1. Download this script to your /usr/local/nagios/libexec/ directory and name it
# check_sharepoint_webpage.sh
# 2. chmod 755 /usr/local/nagios/libexec/check_sharepoint_webpageg.sh 
# (or wherever you put it) 
# 3. Change the user (user) and password (pass) variables within the double 
# quotation marks to match your test account.  IMPORTANT: Avoid exclamation 
# marks in your password.
# 4. Change the target variable within the double quotation marks to match the 
# URL of your sharepoint webpage

# 5. Create a new command in your commands.cfg
# Example:
# define command {
# command_name check_sharepoint_webpage
# command_line $USER1$/check_sharepoint_webpage.sh $HOSTADDRESS$
# }

# 6. Create a new service wherever your services are
# define services{
# use generic-service
# host_name [your hostname]
# service_description check SharePoint Portal webpage
# check_command check_sharepoint_webpage
# }

# 7.  Run the nagios check
# /usr/local/nagios/bin/nagios -v /usr/local/nagios/etc/nagios.cfg
# 8.  Restart nagios if the check passes
# service nagios restart

# NOTES
# Try -k option with your curl if your sharepoint uses ssl

# It is also possible to drill down to a specific page on your SharePoint
# Just don't forget to include any URL encoding in your target.
# Example: target="http://yourSharePointURL/Some%20Department"

user="spdevuaadmin"
pass="Sharep01nt"
target="http://sspwebapp:51000"

pgok="HTTP/1.1 200 OK"

ckc=`curl -s -I --location-trusted --ntlm -u $user:$pass $target`
scr=`echo "$ckc" | sed -n '/HTTP/p'`
gsr=`echo "$scr" | grep "$pgok" 2>&1`

if [ "$?" -eq 0 ]
then
        echo "OK - Page Found: $pgok" 
        exit 0
else
        echo "CRITICAL - SOMETHING HAPPENED"
        exit 2
fi
